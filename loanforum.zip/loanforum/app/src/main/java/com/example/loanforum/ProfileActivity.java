//WIP
//NOT YET IN MANIFEST
package com.example.loanforum;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

public class ProfileActivity extends AppCompatActivity implements View.OnClickListener {
    static private TextView txtUsername, txtEmail, txtCredibility, txtUpvotes, txtPosts;
    static private Button btnReturn;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        txtUsername = findViewById(R.id.profile_txtUsername);
        txtEmail = findViewById(R.id.profile_txtEmail);
        txtCredibility = findViewById(R.id.profile_txtCredibility);
        txtUpvotes = findViewById(R.id.profile_txtUpvotes);
        txtPosts = findViewById(R.id.profile_txtPosts);

        MainActivity.reference.child(MainActivity.uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                UserClass userProfile = snapshot.getValue(UserClass.class);
                if(userProfile != null) {
                    ProfileActivity.txtUsername.setText("Username: " + userProfile.username);
                    ProfileActivity.txtEmail.setText("Email: " + userProfile.email);
                    ProfileActivity.txtCredibility.setText("Credibility: " + Integer.toString(userProfile.credibility));
                    ProfileActivity.txtUpvotes.setText("Upvotes: " + Integer.toString(userProfile.upvotes));
                    ProfileActivity.txtPosts.setText("Posts: " + Integer.toString(userProfile.posts));
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                System.out.println("Error retrieving data");
            }
        });

        btnReturn = findViewById(R.id.profile_btnReturn);
        btnReturn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.profile_btnReturn:
                startActivity(new Intent(this, HomeActivity.class));
                break;
            default:
                break;
        }
    }
}
