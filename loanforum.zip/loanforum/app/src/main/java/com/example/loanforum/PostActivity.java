//FINISHED
//ADDED TO MANIFEST
package com.example.loanforum;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class PostActivity extends AppCompatActivity implements View.OnClickListener {
    private FirebaseUser user;
    private DatabaseReference reference;
    private FirebaseFirestore database;

    private String uid;

    static private EditText txtTitle, txtAmount, txtContent;
    private Button btnPost;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        user = FirebaseAuth.getInstance().getCurrentUser();
        reference = FirebaseDatabase.getInstance().getReference("Users");
        database = FirebaseFirestore.getInstance();
        uid = user.getUid();

        txtTitle = findViewById(R.id.post_txtTitlePrompt);
        txtAmount = findViewById(R.id.post_txtAmountPrompt);
        txtContent = findViewById(R.id.post_txtContentPrompt);
        txtContent.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if(event != null && (event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    InputMethodManager in = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    in.hideSoftInputFromWindow(PostActivity.txtContent.getApplicationWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                }
                PostActivity.txtContent.setTranslationY(0f);
                return false;
            }
        });

        btnPost = findViewById(R.id.post_btnPost);
        btnPost.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.post_btnPost:
                userMakePost();
                break;
            default:
                break;
        }
    }

    private void userMakePost() {
        String inputTitle = txtTitle.getText().toString();
        String inputContent = txtContent.getText().toString();
        int inputAmount = Integer.parseInt(txtAmount.getText().toString());

        if(inputTitle.isEmpty())
            Toast.makeText(this, "Please enter a title", Toast.LENGTH_SHORT).show();
        else if(inputContent.isEmpty())
            Toast.makeText(this, "Please enter a summary", Toast.LENGTH_SHORT).show();
        else if(inputAmount == 0)
            Toast.makeText(this, "Please enter a nonzero amount", Toast.LENGTH_SHORT).show();

        reference.child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                UserClass userProfile = snapshot.getValue(UserClass.class);
                if(userProfile != null) {
                    PostClass post = new PostClass(userProfile.username, userProfile.email, inputTitle, inputContent, inputAmount, userProfile.credibility);
                    database.collection("Posts").add(post).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                        @Override
                        public void onComplete(Task<DocumentReference> task) {
                            if(task.isSuccessful())
                                Toast.makeText(PostActivity.this, "Post successful", Toast.LENGTH_SHORT).show();
                            else
                                Toast.makeText(PostActivity.this, "Post failed\nPlease try again", Toast.LENGTH_SHORT).show();
                        }
                    });

                    MainActivity.reference.child(MainActivity.uid).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot snapshot) {
                            UserClass userProfile = snapshot.getValue(UserClass.class);
                            if(userProfile != null) {
                                Map<String, Object> map = new HashMap<>();
                                map.put("/" + MainActivity.uid + "/posts", (userProfile.posts + 1));
                                MainActivity.reference.updateChildren(map);
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError error) {
                            System.out.println("Error retrieving data");
                        }
                    });

                    startActivity(new Intent(PostActivity.this, HomeActivity.class));
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(PostActivity.this, "Post failed\nPlease try again", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
