//FINISHED
//ADDED TO MANIFEST
package com.example.loanforum;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class InfoActivity extends AppCompatActivity implements View.OnClickListener {
    private QueryDocumentSnapshot current;
    private DocumentReference reference;

    public static ArrayList<QueryDocumentSnapshot> postlist;

    private TextView txtTitle, txtUsername, txtEmail, txtAmount, txtDate, txtCredibility, txtContent;
    private RelativeLayout relayLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        current = HomeActivity.postlist.get(HomeActivity.position);
        reference = current.getReference();

        txtTitle = findViewById(R.id.info_txtTitle);
        txtTitle.setText(current.getData().get("title").toString());
        txtUsername = findViewById(R.id.info_txtUsername);
        txtUsername.setText("Username: " + current.getData().get("username").toString());
        txtEmail = findViewById(R.id.info_txtEmail);
        txtEmail.setText("Email: " + current.getData().get("email").toString());
        txtAmount = findViewById(R.id.info_txtAmount);
        txtAmount.setText("Amount: " + current.getData().get("amount").toString());
        txtDate = findViewById(R.id.info_txtDate);
        txtDate.setText("Date: " + current.getData().get("date").toString());
        txtCredibility = findViewById(R.id.info_txtCredibility);
        txtCredibility.setText("Credibility: " + current.getData().get("credibility").toString());
        txtContent = findViewById(R.id.info_txtContent);
        txtContent.setText(current.getData().get("content").toString());

        relayLayout = findViewById(R.id.info_relayLayout);
        relayLayout.setOnClickListener(this);
        relayLayout.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                reference.update("upvote", (Integer.parseInt(current.getData().get("upvote").toString()) + 1));

                MainActivity.reference.child(MainActivity.uid).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        UserClass userProfile = snapshot.getValue(UserClass.class);
                        if(userProfile != null) {
                            Map<String, Object> map = new HashMap<>();
                            map.put("/" + MainActivity.uid + "/upvotes", (userProfile.upvotes + 1));
                            MainActivity.reference.updateChildren(map);
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        System.out.println("Error retrieving data");
                    }
                });

                Toast.makeText(InfoActivity.this, "Upvoted", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(InfoActivity.this, HomeActivity.class));
                return false;
            }
        });

    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.info_relayLayout:
                startActivity(new Intent(this, HomeActivity.class));
                break;
            default:
                break;
        }
    }
}