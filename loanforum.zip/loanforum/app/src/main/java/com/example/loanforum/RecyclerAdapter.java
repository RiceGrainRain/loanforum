//FINISHED
package com.example.loanforum;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder> {
    private ArrayList<QueryDocumentSnapshot> postlist;

    private OnPostListener mpostListener;

    public RecyclerAdapter(ArrayList<QueryDocumentSnapshot> l, OnPostListener m) {
        postlist = l;
        mpostListener = m;
    }

    public interface OnPostListener {
        void onPostClick(int p);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView txtTitle;
        private TextView txtInfo;
        private OnPostListener mpostListener;

        public MyViewHolder(View view, OnPostListener m) {
            super(view);
            txtTitle = view.findViewById(R.id.li_txtTitle);
            txtInfo = view.findViewById(R.id.li_txtInfo);
            mpostListener = m;

            view.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            mpostListener.onPostClick(getAdapterPosition());
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);
        return new MyViewHolder(itemView, mpostListener);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        QueryDocumentSnapshot current = postlist.get(position);
        String setTitle = current.getData().get("title").toString();
        String setInfo = "Username: " + current.getData().get("username").toString() + "\t|\tCredibility: " + current.getData().get("credibility").toString();
        holder.txtTitle.setText(setTitle);
        holder.txtInfo.setText(setInfo);
    }

    @Override
    public int getItemCount() {
        return postlist.size();
    }
}
