//FINISHED
package com.example.loanforum;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class PostClass {
    public String username, email, title, content, date;

    public int amount, credibility, upvote;

    private Calendar calendar;

    public PostClass() {}

    public PostClass(String u, String e, String t, String c, int a, int cr) {
        username = u;
        email = e;
        title = t;
        content = c;

        amount = a;
        credibility = cr;
        upvote = 0;

        calendar = Calendar.getInstance();
        date = (calendar.get(Calendar.MONTH) + 1) + "/" + calendar.get(Calendar.DATE) + "/" + calendar.get(Calendar.YEAR);

        System.out.println(amount);
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public int getAmount() {
        return amount;
    }

    public int getCredibility() {
        return credibility;
    }

    public int getUpvote() {return upvote;}

    public String getDate() {
        return date;
    }
}
