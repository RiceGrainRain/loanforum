//FINISHED
//ADDED TO MANIFEST
package com.example.loanforum;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private FirebaseAuth mAuth;
    static public FirebaseUser globaluser;
    static public DatabaseReference reference;

    static public String uid;

    private EditText txtEmail, txtPassword;
    private Button btnLogin, btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String release = Build.VERSION.RELEASE;
        int sdkVersion = Build.VERSION.SDK_INT;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();

        txtEmail = findViewById(R.id.main_txtEmailPrompt);
        txtPassword = findViewById(R.id.main_txtPasswordPrompt);

        btnLogin = findViewById(R.id.main_btnLogin);
        btnLogin.setOnClickListener(this);
        btnRegister = findViewById(R.id.main_btnRegister);
        btnRegister.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.main_btnLogin:
                userLogin();
                break;
            case R.id.main_btnRegister:
                startActivity(new Intent(this, RegisterActivity.class));
                break;
            default:
                break;
        }
    }

    private void userLogin() {
        String inputEmail = txtEmail.getText().toString();
        String inputPassword = txtPassword.getText().toString();

        if(inputEmail.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(inputEmail).matches()) {
            Toast.makeText(this, "Please enter a valid Email address", Toast.LENGTH_SHORT).show();
            return;
        }
        else if(inputPassword.isEmpty() || inputPassword.length() < 6) {
            Toast.makeText(this, "Please enter a valid password\nLength must be greater than 6", Toast.LENGTH_SHORT).show();
            return;
        }

        mAuth.signInWithEmailAndPassword(inputEmail, inputPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()) {
                    MainActivity.globaluser = FirebaseAuth.getInstance().getCurrentUser();
                    MainActivity.reference = FirebaseDatabase.getInstance().getReference("Users");
                    MainActivity.uid = globaluser.getUid();
                    Toast.makeText(MainActivity.this, "Login success", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(MainActivity.this, HomeActivity.class));
                }
                else
                    Toast.makeText(MainActivity.this, "Login failed\nPlease try again", Toast.LENGTH_SHORT).show();
            }
        });
    }
}