//FINISHED
package com.example.loanforum;

public class UserClass {
    public String username, email;
    public int credibility, posts, upvotes;

    public UserClass() {}

    public UserClass(String u, String e) {
        username = u;
        email = e;
        credibility = 50;
        posts = 0;
        upvotes = 0;
    }
}
