//ADDED TO MANIFEST
package com.example.loanforum;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Collections;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener, RecyclerAdapter.OnPostListener {
    private FirebaseFirestore database;
    private CollectionReference reference;
    private Query query;

    public static ArrayList<QueryDocumentSnapshot> postlist;
    public static int position;

    private RecyclerView display;
    private Button btnPost, btnProfile;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        System.out.println(MainActivity.uid);

        database = FirebaseFirestore.getInstance();
        reference = database.collection("Posts");
        query = reference.orderBy("upvote");
        query.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()) {
                    for(QueryDocumentSnapshot post : task.getResult())
                        HomeActivity.postlist.add(post);
                    Collections.reverse(postlist);
                    setRecyclerAdapter();
                }
            }
        });

        postlist = new ArrayList<>();

        display = findViewById(R.id.home_rcvwDisplay);

        btnPost = findViewById(R.id.home_btnPost);
        btnPost.setOnClickListener(this);
        btnProfile = findViewById(R.id.home_btnProfile);
        btnProfile.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.home_btnPost:
                startActivity(new Intent(this, PostActivity.class));;
                break;
            case R.id.home_btnProfile:
                startActivity(new Intent(this, ProfileActivity.class));
                break;
            default:
                break;
        }
    }

    @Override
    public void onPostClick(int p) {
        position = p;
        startActivity(new Intent(this, InfoActivity.class));
    }

    public void setRecyclerAdapter() {
        RecyclerAdapter adapt = new RecyclerAdapter(postlist, this);
        RecyclerView.LayoutManager layout = new LinearLayoutManager(this);
        display.setLayoutManager(layout);
        display.setItemAnimator(new DefaultItemAnimator());
        display.setAdapter(adapt);
    }
}
