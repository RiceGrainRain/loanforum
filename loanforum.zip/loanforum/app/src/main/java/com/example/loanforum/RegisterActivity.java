//FINISHED
//ADDED TO MANIFEST
package com.example.loanforum;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {
    private FirebaseAuth mAuth;

    private EditText txtEmail, txtUsername, txtPassword, txtConfirm;
    private Button btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();

        txtEmail = findViewById(R.id.regis_txtEmailPrompt);
        txtUsername = findViewById(R.id.regis_txtUsernamePrompt);
        txtPassword = findViewById(R.id.regis_txtPasswordPrompt);
        txtConfirm = findViewById(R.id.regis_txtAmountPrompt);

        btnRegister = findViewById(R.id.regis_btnRegister);
        btnRegister.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.regis_btnRegister:
                userMakeAccount();
                break;
            default:
                break;
        }
    }

    private void userMakeAccount() {
        String inputUsername = txtUsername.getText().toString();
        String inputEmail = txtEmail.getText().toString();
        String inputPassword = txtPassword.getText().toString();
        String inputConfirm = txtConfirm.getText().toString();

        if(inputEmail.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(inputEmail).matches()) {
            Toast.makeText(this, "Please enter valid Email address", Toast.LENGTH_SHORT).show();
            return;
        }
        else if(inputUsername.isEmpty()) {
            Toast.makeText(this, "Please enter a valid username", Toast.LENGTH_SHORT).show();
            return;
        }
        else if(inputPassword.isEmpty() || inputPassword.length() < 6) {
            Toast.makeText(this, "Please enter a valid password\nLength must be greater than 6", Toast.LENGTH_SHORT).show();
            return;
        }
        else if(!inputPassword.equals(inputConfirm)) {
            Toast.makeText(this, "Password does not match", Toast.LENGTH_SHORT).show();
            return;
        }

        mAuth.createUserWithEmailAndPassword(inputEmail, inputPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()) {
                    UserClass user = new UserClass(inputUsername, inputEmail);
                    FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful())
                                Toast.makeText(RegisterActivity.this, "Registration success", Toast.LENGTH_SHORT).show();
                            else
                                Toast.makeText(RegisterActivity.this, "Registration failed\nPlease try again", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                else
                    Toast.makeText(RegisterActivity.this, "Registration failed\nPlease try again", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(RegisterActivity.this, MainActivity.class));
            }
        });
    }
}
